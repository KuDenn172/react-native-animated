export default [
  require('../../images/facebook-emojis/like.gif'),
  require('../../images/facebook-emojis/love.gif'),
  require('../../images/facebook-emojis/haha.gif'),
  require('../../images/facebook-emojis/wow.gif'),
  require('../../images/facebook-emojis/sad.gif'),
];
