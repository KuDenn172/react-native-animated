export const musicData = [
  {
    id: '0',
    image: require('../images/zing/1.png'),
    bannerImage: require('../images/zing/1banner.jpeg'),
  },
  {
    id: '1',
    image: require('../images/zing/2.png'),
    bannerImage: require('../images/zing/2banner.jpeg'),
  },
  {
    id: '2',
    image: require('../images/zing/3.png'),
    bannerImage: require('../images/zing/3banner.jpeg'),
  },
  {
    id: '3',
    image: require('../images/zing/4.png'),
    bannerImage: require('../images/zing/4banner.jpeg'),
  },
  {
    id: '4',
    image: require('../images/zing/5.png'),
    bannerImage: require('../images/zing/5banner.jpeg'),
  },
  {
    id: '5',
    image: require('../images/zing/6.png'),
    bannerImage: require('../images/zing/6banner.jpeg'),
  },
];
