import React from 'react';
import MainStackNavigator from './src/animations/MainStackNavigator';

const App = () => {
  return <MainStackNavigator />;
};

export default App;
