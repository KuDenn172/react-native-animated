# React Native Animations

## Installation

Using npm:

```shell
npm install
```

or using yarn:

```shell
yarn
```

Run `npx pod-install`

## Join Minh Techie community

**Youtube**

https://www.youtube.com/channel/UCGxA-PuYBXinpwGawUqEYpg

**Facebook**

https://www.facebook.com/groups/minhtechie

**Support me**

https://www.buymeacoffee.com/minhtechiejs  




https://user-images.githubusercontent.com/68360917/170456771-a43f8846-29a9-4eeb-be2f-1cca82a1178e.mov

